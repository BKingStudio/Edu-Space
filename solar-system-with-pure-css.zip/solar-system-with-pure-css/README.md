# Solar System with Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/yashbhardwaj/pen/wvzzeV](https://codepen.io/yashbhardwaj/pen/wvzzeV).

Check out My Solar System with actual velocites!